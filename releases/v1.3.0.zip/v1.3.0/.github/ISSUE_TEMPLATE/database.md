---
name: Database
about: Create a report concerning database issues
title: "[Database] <Your bug here>"
labels: ''
assignees: ''

---

Please provide the following details: 
* VEBA release version: 
* Script version of `download_databases.sh` found at top of script (Note: Release v1.0.0 does not have a version here): 
* Log file: 
* Error message:
