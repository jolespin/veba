### Installation and Database Configuration Guide
____________________________________________________________
#### Software installation
One issue with having large-scale pipeline suites with open-source software is the issue of dependencies.  One solution for this is to have a modular software structure where each module has its own `conda` environment.  This allows for minimizing dependency constraints as this software suite uses an array of diverse packages from different developers. 

The basis for these environments is creating a separate environment for each module with the `VEBA-` prefix and `_env` as the suffix.  For example `VEBA-assembly_env` or `VEBA-binning-prokaryotic_env`.  Because of this, `VEBA` is currently not available as a `conda` package but each module will be in the near future.  In the meantime, please use the `veba/install/install_veba.sh` script which installs each environment from the yaml files in `veba/install/environments/`. After installing the environments, use the `veba/install/download_databases` script to download and configure the databases while also adding the environment variables to the activate/deactivate scripts in each environment.  To install anything manually, just read the scripts as they are well documented and refer to different URL and paths for specific installation options.

The majority of the time taken to build database is downloading/decompressing large archives, `Diamond` database creation of UniRef, and `MMSEQS2` database creation of microeukaryotic protein database.

Total size is `214 GB` but if you have certain databases installed already then you can just symlink them so the `VEBA_DATABASE` path has the correct structure.  Note, the exact size may vary as Pfam and UniRef are updated regularly.

Each major version will be packaged as a [release](https://github.com/jolespin/veba/releases) which will include a log of module and script versions. 

**Download Anaconda:** 
[https://www.anaconda.com/products/distribution](https://www.anaconda.com/products/distribution)

____________________________________________________________

⚠️ **Read before updating from `v1.0.x `→ `v1.1.x`:**

If you are updating from `v1.0.x` → `v1.1.x` it is strongly recommended to uninstall your current installation and install from the beginning as this removes all the existing `VEBA` `conda` environments.  In `v1.1.x` many modules are trimmed down and more efficient in their dependencies.  To be clear, `v1.1.x` also uses an updated database which is `vDB_v4`.
____________________________________________________________

### Install:

Currently, **Conda environments for VEBA are ONLY configured for Linux**.  MacOS configs for certain environments will be available for v2.x.x. Due to the large databases, this software was designed to be used via HPC. 

**There are 3 steps to install *VEBA*:**

* Download repository from GitHub

* Install conda environments

* Download/configure databases

**0. Clean up your conda installation [Optional, but recommended]**

The `VEBA` installation is going to configure some `conda` environments for you and some of them have quite a bit of packages.  To minimize the likelihood of [weird errors](https://forum.qiime2.org/t/valueerror-unsupported-format-character-t-0x54-at-index-3312-when-creating-environment-from-environment-file/25237), it's recommended to do the following:


* Use this as your [`~/.condarc`](https://conda.io/projects/conda/en/latest/user-guide/configuration/use-condarc.html).  If you're not familiar with the `.condarc` file, then you probably don't have one configured.  You can use an editor like [nano](https://anaconda.org/conda-forge/nano) (which is what I use), [vim](https://anaconda.org/conda-forge/vim), or [emacs](https://anaconda.org/conda-forge/emacs) to copy/paste the following into `~/.condarc`.
	
	```
	channel_priority: flexible
	channels:
	  - conda-forge
	  - bioconda
	  - jolespin
	  - defaults
	  - qiime2
		
	report_errors: true
	```
	
* Make sure your `conda` is [initialized](https://docs.conda.io/projects/conda/en/latest/commands/init.html). I use `bash` for my initialization.  
	
	```
	conda init bash
	```
	
	
* Clean up your `conda` environment with the following command.
	
	```
	conda clean --all -y
	```
	
* Update your `conda`.
	
	```
	conda update -n base --all -y
	```
	
* Install and update [`mamba`](https://mamba.readthedocs.io/en/latest/installation.html).
	
	```
	conda install -c conda-forge mamba -y
	conda update mamba -y
	```

**1. Download repository**

```
# For stable version, download and decompress the tarball:

VERSION="1.1.1"
wget https://github.com/jolespin/veba/archive/refs/tags/v${VERSION}.tar.gz
tar -xvf v${VERSION}.tar.gz && mv veba-${VERSION} veba

# For developmental version, clone the repository:
# git clone https://github.com/jolespin/veba/

# Update the permissions
chmod 755 veba/src/*.py
chmod 755 veba/src/scripts/*
chmod 755 veba/install/*.sh

# Go into the install directory
cd veba/install
``` 

**2. Install VEBA environments**

**Recommended resource allocatation:** 4 hours with 15 GB memory (include extra time for variable I/O speed for various hosts)

For `v1.1.0+`, **this should take ~1.75 hours (~108 minutes) with ~15 GB memory allocated**.  The update from `CheckM1` -> `CheckM2` and installation of `antiSMASH` require more memory and may require grid access if head node is limited.

```
bash install_veba.sh
```

**3. Activate the database conda environment, download, and configure databases**

**Recommended resource allocatation:**  48 GB memory (time is dependent on I/O of database repositories)

⚠️ **This step should use up to 48 GB memory** and should be run using a compute grid via SLURM or SunGridEngine.  If this command is run on the head node it will likely fail or timeout if a connection is interrupted. The most computationally intensive steps are creating a `Diamond` database of NCBI's non-redundant reference and a `MMSEQS2` database of the microeukaryotic protein database.  Note the duration will depend on several factors including your internet connection speed and the i/o of public repositories.

If issues arise, please [submit a GitHub issue](https://github.com/jolespin/veba/issues) prefixed with `[Database]`. We are here to help :)

**If you are running an interactive queue:**

```
conda activate VEBA-database_env

bash download_databases.sh /path/to/veba_database
```

**If you use job scheduling (e.g., sbatch or qsub):**

[If you're unfamiliar with SLURM or SunGridEnginer, we got you](https://github.com/jolespin/veba/blob/main/walkthroughs/README.md#basics).  

Running `conda activate` on a compute server might prompt you to run `conda init` even if you've already initilized on the head node.  To get around this you can use `source activate [environment]`.  Using the `source activate` command requires you to be in `base` conda environment.  You can do this via `conda deactivate` or `conda activate base` before you submit your job.  

Below is an example of how to do this: 

```
# Activate your base environment
conda activate base

# Set the number of threads you want to use.  
# Keep in mind that not all steps are parallelized (e.g., wget)
N_JOBS=1

# Create a log directory
mkdir -p logs/

# Set name for log files when running on the grid
N="database_config"

# Adapt your command to a one-liner
CMD="source activate VEBA-database_env && bash download_databases.sh /path/to/veba_database"
	
# Note: You should either use SunGridEngine or SLURM not both. 
# You might need to adapt slightly but these worked on our systems.

# SunGridEngine:
qsub -o logs/${N}.o -e logs/${N}.e -cwd -N ${N} -j y -pe threaded ${N_JOBS} "${CMD}"
	
# SLURM:
# For SLURM you might need to specify which account and partition you are associated with for grid jobs
PARTITION=[partition name]
ACCOUNT=[account name]

sbatch -A ${ACCOUNT} -p ${PARTITION} -J ${N} -N 1 -c ${N_JOBS} --ntasks-per-node=1 -o logs/${N}.o -e logs/${N}.e --export=ALL -t 12:00:00 --mem=64G --wrap="${CMD}"
```

Now, you should have the following environments:

```
VEBA-annotate_env
VEBA-assembly_env
VEBA-binning-eukaryotic_env
VEBA-binning-prokaryotic_env
VEBA-binning-viral_env
VEBA-biosynthetic_env
VEBA-classify_env
VEBA-cluster_env
VEBA-database_env
VEBA-mapping_env
VEBA-phylogeny_env
VEBA-preprocess_env
```
All the environments should have the `VEBA_DATABASE` environment variable set. If not, then add it manually to ~/.bash_profile: `export VEBA_DATABASE=/path/to/veba_database`.

You can check to make sure the `conda` environments were created and all of the environment variables were created using the following command:

```
bash check_installation.sh
```

Future versions will have `bioconda` installation available.

#### Alternatively, if you just need to update environment variables with existing database:

```
bash update_environment_variables.sh
```

**If you want to use containerized versions:**

Please refer to the [adapting commands for Docker walkthrough](https://github.com/jolespin/veba/blob/main/walkthroughs/adapting_commands_for_docker.md).


____________________________________________________________

### Uninstall:

**There are 2 steps to uninstall *VEBA*:**

* Remove conda environments

* Remove database directory

```
# Remove conda enivronments
bash uninstall_veba.sh

# Remove VEBA database
rm -rfv /path/to/veba_database
```
____________________________________________________________

### Updating VEBA: 

There are currently 2 ways to update veba:

1. Basic uninstall reinstall - You can uninstall and reinstall using the scripts in `veba/install/` directory.  It's recomended to do a fresh reinstall when updating from `v1.0.x` → `v1.1.x`.
2. Patching existing installation - Complete reinstalls of *VEBA* environments and databases is time consuming so [we've detailed how to do specific patches **for advanced users**](PATCHES.md). If you don't feel comfortable running these commands, then just do a fresh install if you would like to update. 


### VEBA Containers [Coming Soon]:


| Environment                  | Environment File                 | Resources              | Description                                                                                                              | Recommended Threads | Description                                                                                                     |
|------------------------------|----------------------------------|------------------------|--------------------------------------------------------------------------------------------------------------------------|---------------------|-----------------------------------------------------------------------------------------------------------------|
| VEBA-annotate_env            | VEBA-annotate_env.yml            | 16GB-128GB             | Annotating proteins with Diamond, HMMER, and KOFAM                                                                       | 4                   | Fastq quality trimming, adapter removal, decontamination, and read statistics calculations                      |
| VEBA-assembly_env            | VEBA-assembly_env.yml            | 32GB-128GB             | Assembling metagenomes/metatranscriptomes, mapping reads to assemblies,   and preparing for genome binning               | 16                  | Assemble reads, align reads to assembly, and count mapped reads                                                 |
| VEBA-biosynthetic_env        | VEBA-biosynthetic_env.yml        | 16GB                   | BGC detection with antiSMASH, convert genbank files to tabular format,   assess novelty of BGC                           | 16                  | Align reads to (concatenated) reference and counts mapped reads                                                 |
| VEBA-preprocess_env          | VEBA-preprocess_env.yml          | 4GB-16GB               | Preprocess reads by quality filtering, removing adapters, removing human   contamination, and properly pairing           | 4                   | Iterative consensus binning for recovering prokaryotic genomes with lineage-specific quality assessment         |
| VEBA-binning-eukaryotic_env  | VEBA-binning-eukaryotic_env.yml  | 128GB                  | Binning for recovering eukaryotic genomes with exon-aware gene modeling   and lineage-specific quality assessment        | 4                   | Binning for recovering eukaryotic genomes with exon-aware gene modeling and lineage-specific quality assessment |
| VEBA-binning-prokaryotic_env | VEBA-binning-prokaryotic_env.yml | 16GB                   | Iterative consensus binning for recovering prokaryotic genomes with   lineage-specific quality assessment                | 4                   | Detection of viral genomes and quality assessment                                                               |
| VEBA-binning-viral_env       | VEBA-binning-viral_env.yml       | 16GB                   | Detection of viral genomes and quality assessment                                                                        | 32                  | Taxonomic classification and candidate phyla radiation adjusted quality                                         |
| VEBA-classify_env            | VEBA-classify_env.yml            | 16GB-64GB              | Classify eukaryotic, prokaryotic, and viral genomes                                                                      | 1                   | Taxonomic classification of eukaryotic genomes                                                                  |
| VEBA-cluster_env             | VEBA-cluster_env.yml             | 32GB                   | Species-level clustering of genomes and lineage-specific orthogroup   detection.                                         | 4                   | Taxonomic classification and isolation source of viral genomes                                                  |
| VEBA-database_env            | VEBA-database_env.yml            | 64GB                   | Contains all the programs needed to download and build the VEBA database                                                 | 32                  | Species-level clustering of genomes and lineage-specific orthogroup detection                                   |
| VEBA-mapping_env             | VEBA-mapping_env.yml             | 16GB                   | Aligns reads to local or global index of genomes. By default uses Bowtie2   but future versions will use Salmon as well. | 32                  | Annotates translated gene calls against UniRef, Pfam, and KOFAM                                                     |
| VEBA-phylogeny_env           | VEBA-phylogeny_env.yml           | 16+GB                  | Constructs phylogenetic trees given a marker set using concatenated   protein alignments                                 | 32                  | Constructs phylogenetic trees given a marker set                                                                |
| Stable                       | VEBA-mapping_env                 | index.py               | 16GB                                                                                                                     | 4                   | Builds local or global index for alignment to genomes                                                           |
| Stable                       | VEBA-mapping_env                 | mapping.py             | 16GB                                                                                                                     | 4                   | Aligns reads to local or global index of genomes                                                                |
| Developmental                | VEBA-biosynthetic_env            | biosynthetic.py        | 16GB                                                                                                                     | 16                  | Identify biosynthetic gene clusters in prokaryotes and fungi                                                    |
| Developmental                | VEBA-assembly_env                | assembly-sequential.py | 32GB-128GB+                                                                                                              | 16                  | Assemble metagenomes sequentially                                                                               |
| Developmental                | VEBA-amplicon_env                | amplicon.py            | 96GB                                                                                                                     | 16                  | Automated read trim position detection, DADA2 ASV detection, taxonomic classification, and file conversion      |
____________________________________________________________

### VEBA Database:


#### Profile HMM Sources:
Please cite the following sources if these marker sets are used in any way:

```
* Archaea_76.hmm.gz - (Anvi'o) Lee, https://doi.org/10.1093/bioinformatics/btz188 (https://github.com/merenlab/anvio/tree/master/anvio/data/hmm/Archaea_76)

* Bacteria_71.hmm.gz - (Anvi'o) Lee modified, https://doi.org/10.1093/bioinformatics/btz188 (https://github.com/merenlab/anvio/tree/master/anvio/data/hmm/Bacteria_71)

* Protista_83.hmm.gz - (Anvi'o) Delmont, http://merenlab.org/delmont-euk-scgs (https://github.com/merenlab/anvio/tree/master/anvio/data/hmm/Protista_83)

* Fungi_593.hmm.gz - (FGMP) https://bmcbioinformatics.biomedcentral.com/articles/10.1186/s12859-019-2782-9

* CPR_43.hmm.gz - (CheckM) https://github.com/Ecogenomics/CheckM/tree/master/custom_marker_sets

* eukaryota_odb10.hmm.gz - (BUSCO) https://busco-data.ezlab.org/v5/data/lineages/eukaryota_odb10.2020-09-10.tar.gz
```

Espinoza, Josh (2022): Profile HMM marker sets. figshare. Dataset. https://doi.org/10.6084/m9.figshare.19616016.v1 

#### Microeukaryotic protein database:
A protein database is required not only for eukaryotic gene calls using MetaEuk but can also be used for MAG annotation.  Many eukaryotic protein databases exist such as MMETSP, EukZoo, and EukProt, yet these are limited to marine environments, include prokaryotic sequences, or include eukaryotic sequences for organisms that would not be expected to be binned out of metagenomes such as metazoans.  We combined and dereplicated MMETSP, EukZoo, EukProt, and NCBI non-redundant to include only microeukaryotes such as protists and fungi.  This optimized microeukaryotic database ensures that only eukaryotic exons expected to be represented in metagenomes are utilized for eukaryotic gene modeling and the resulting MetaEuk reference targets are used for eukaryotic MAG classification.  VEBA’s microeukaryotic protein database includes 48,006,918 proteins from 42,922 microeukaryotic strains.  

**Current:**

* [VDB-Microeukaryotic\_v2.1](https://zenodo.org/record/7485114) available on Zenodo

**Deprecated:**

* [VDB-Microeukaryotic\_v1](https://figshare.com/articles/dataset/Microeukaryotic_Protein_Database/19668855) available on FigShare

#### Database Structure:

**Current:**
*VEBA Database* version: `VDB_v5`
`VDB_v4` → `VDB_v5` replaces `nr` with `UniRef90` and `UniRef50`.  Also includes `MiBIG` database.

```
tree -L 3 .
├── ACCESS_DATE
├── Annotate
│   ├── KOFAM
│   │   ├── ko_list
│   │   └── profiles
│   ├── MIBiG
│   │   └── mibig_v3.1.dmnd
│   ├── NCBIfam-AMRFinder
│   │   ├── NCBIfam-AMRFinder.changelog.txt
│   │   ├── NCBIfam-AMRFinder.hmm.gz
│   │   └── NCBIfam-AMRFinder.tsv
│   ├── Pfam
│   │   ├── Pfam-A.hmm.gz
│   │   └── relnotes.txt
│   └── UniRef
│       ├── uniref50.dmnd
│       └── uniref90.dmnd
├── Classify
│   ├── CheckM2
│   │   └── uniref100.KO.1.dmnd
│   ├── CheckV
│   │   ├── genome_db
│   │   ├── hmm_db
│   │   └── README.txt
│   ├── geNomad
│   │   ├── genomad_db
│   │   ├── genomad_db.dbtype
│   │   ├── genomad_db_h
│   │   ├── genomad_db_h.dbtype
│   │   ├── genomad_db_h.index
│   │   ├── genomad_db.index
│   │   ├── genomad_db.lookup
│   │   ├── genomad_db_mapping
│   │   ├── genomad_db.source
│   │   ├── genomad_db_taxonomy
│   │   ├── genomad_integrase_db
│   │   ├── genomad_integrase_db.dbtype
│   │   ├── genomad_integrase_db_h
│   │   ├── genomad_integrase_db_h.dbtype
│   │   ├── genomad_integrase_db_h.index
│   │   ├── genomad_integrase_db.index
│   │   ├── genomad_integrase_db.lookup
│   │   ├── genomad_integrase_db.source
│   │   ├── genomad_marker_metadata.tsv
│   │   ├── genomad_mini_db -> genomad_db
│   │   ├── genomad_mini_db.dbtype
│   │   ├── genomad_mini_db_h -> genomad_db_h
│   │   ├── genomad_mini_db_h.dbtype -> genomad_db_h.dbtype
│   │   ├── genomad_mini_db_h.index -> genomad_db_h.index
│   │   ├── genomad_mini_db.index
│   │   ├── genomad_mini_db.lookup -> genomad_db.lookup
│   │   ├── genomad_mini_db_mapping -> genomad_db_mapping
│   │   ├── genomad_mini_db.source -> genomad_db.source
│   │   ├── genomad_mini_db_taxonomy -> genomad_db_taxonomy
│   │   ├── mini_set_ids
│   │   ├── names.dmp
│   │   ├── nodes.dmp
│   │   ├── plasmid_hallmark_annotation.txt
│   │   ├── version.txt
│   │   └── virus_hallmark_annotation.txt
│   ├── GTDBTk
│   │   ├── fastani
│   │   ├── markers
│   │   ├── masks
│   │   ├── metadata
│   │   ├── mrca_red
│   │   ├── msa
│   │   ├── pplacer
│   │   ├── radii
│   │   ├── split
│   │   ├── taxonomy
│   │   └── temp
│   ├── Microeukaryotic
│   │   ├── humann_uniref50_annotations.tsv.gz
│   │   ├── md5_checksums
│   │   ├── microeukaryotic
│   │   ├── microeukaryotic.dbtype
│   │   ├── microeukaryotic.eukaryota_odb10
│   │   ├── microeukaryotic.eukaryota_odb10.dbtype
│   │   ├── microeukaryotic.eukaryota_odb10_h
│   │   ├── microeukaryotic.eukaryota_odb10_h.dbtype
│   │   ├── microeukaryotic.eukaryota_odb10_h.index
│   │   ├── microeukaryotic.eukaryota_odb10.index
│   │   ├── microeukaryotic.eukaryota_odb10.lookup
│   │   ├── microeukaryotic.eukaryota_odb10.source
│   │   ├── microeukaryotic_h
│   │   ├── microeukaryotic_h.dbtype
│   │   ├── microeukaryotic_h.index
│   │   ├── microeukaryotic.index
│   │   ├── microeukaryotic.lookup
│   │   ├── microeukaryotic.source
│   │   ├── reference.eukaryota_odb10.list
│   │   ├── RELEASE_NOTES
│   │   ├── source_taxonomy.tsv.gz
│   │   ├── source_to_lineage.dict.pkl.gz
│   │   └── target_to_source.dict.pkl.gz
│   └── NCBITaxonomy
│       ├── citations.dmp
│       ├── delnodes.dmp
│       ├── division.dmp
│       ├── gc.prt
│       ├── gencode.dmp
│       ├── images.dmp
│       ├── merged.dmp
│       ├── names.dmp
│       ├── nodes.dmp
│       ├── prot.accession2taxid.FULL.gz
│       └── readme.txt
├── Contamination
│   ├── AntiFam
│   │   ├── AntiFam.hmm.gz
│   │   ├── relnotes
│   │   └── version
│   ├── chm13v2.0
│   │   ├── chm13v2.0.1.bt2
│   │   ├── chm13v2.0.2.bt2
│   │   ├── chm13v2.0.3.bt2
│   │   ├── chm13v2.0.4.bt2
│   │   ├── chm13v2.0.rev.1.bt2
│   │   └── chm13v2.0.rev.2.bt2
│   └── kmers
│       └── ribokmers.fa.gz
└── MarkerSets
    ├── Archaea_76.hmm.gz
    ├── Bacteria_71.hmm.gz
    ├── CPR_43.hmm.gz
    ├── eukaryota_odb10.hmm.gz
    ├── eukaryota_odb10.scores_cutoff.tsv.gz
    ├── Fungi_593.hmm.gz
    ├── Protista_83.hmm.gz
    └── README
```


**Deprecated:**

<details>
	<summary> *VEBA Database* version: `VDB_v4` </summary>
	

`VDB_v4` is `VDB_v3.1` with the following changes: 1) `CheckM1` database swapped for `CheckM2` database;  includes `geNomad` database; and 3) updates `CheckV` database.  Refer to [development log](https://github.com/jolespin/veba/blob/main/DEVELOPMENT.md#release-v11-currently-testing-before-official-release) for specifics.

```
tree -L 3 .
.
├── ACCESS_DATE
├── Annotate
│   ├── KOFAM
│   │   ├── ko_list
│   │   └── profiles
│   ├── NCBIfam-AMRFinder
│   │   ├── NCBIfam-AMRFinder.changelog.txt
│   │   ├── NCBIfam-AMRFinder.hmm.gz
│   │   └── NCBIfam-AMRFinder.tsv
│   ├── nr
│   │   └── nr.dmnd
│   └── Pfam
│       ├── Pfam-A.hmm.gz
│       └── relnotes.txt
├── Classify
│   ├── CheckM2
│   │   └── uniref100.KO.1.dmnd
│   ├── CheckV
│   │   ├── genome_db
│   │   ├── hmm_db
│   │   └── README.txt
│   ├── geNomad
│   │   ├── genomad_db
│   │   ├── genomad_db.dbtype
│   │   ├── genomad_db_h
│   │   ├── genomad_db_h.dbtype
│   │   ├── genomad_db_h.index
│   │   ├── genomad_db.index
│   │   ├── genomad_db.lookup
│   │   ├── genomad_db_mapping
│   │   ├── genomad_db.source
│   │   ├── genomad_db_taxonomy
│   │   ├── genomad_integrase_db
│   │   ├── genomad_integrase_db.dbtype
│   │   ├── genomad_integrase_db_h
│   │   ├── genomad_integrase_db_h.dbtype
│   │   ├── genomad_integrase_db_h.index
│   │   ├── genomad_integrase_db.index
│   │   ├── genomad_integrase_db.lookup
│   │   ├── genomad_integrase_db.source
│   │   ├── genomad_marker_metadata.tsv
│   │   ├── genomad_mini_db -> genomad_db
│   │   ├── genomad_mini_db.dbtype
│   │   ├── genomad_mini_db_h -> genomad_db_h
│   │   ├── genomad_mini_db_h.dbtype -> genomad_db_h.dbtype
│   │   ├── genomad_mini_db_h.index -> genomad_db_h.index
│   │   ├── genomad_mini_db.index
│   │   ├── genomad_mini_db.lookup -> genomad_db.lookup
│   │   ├── genomad_mini_db_mapping -> genomad_db_mapping
│   │   ├── genomad_mini_db.source -> genomad_db.source
│   │   ├── genomad_mini_db_taxonomy -> genomad_db_taxonomy
│   │   ├── mini_set_ids
│   │   ├── names.dmp
│   │   ├── nodes.dmp
│   │   ├── plasmid_hallmark_annotation.txt
│   │   ├── version.txt
│   │   └── virus_hallmark_annotation.txt
│   ├── GTDBTk
│   │   ├── fastani
│   │   ├── markers
│   │   ├── masks
│   │   ├── metadata
│   │   ├── mrca_red
│   │   ├── msa
│   │   ├── pplacer
│   │   ├── radii
│   │   ├── split
│   │   ├── taxonomy
│   │   └── temp
│   ├── Microeukaryotic
│   │   ├── humann_uniref50_annotations.tsv.gz
│   │   ├── md5_checksums
│   │   ├── microeukaryotic
│   │   ├── microeukaryotic.dbtype
│   │   ├── microeukaryotic.eukaryota_odb10
│   │   ├── microeukaryotic.eukaryota_odb10.dbtype
│   │   ├── microeukaryotic.eukaryota_odb10_h
│   │   ├── microeukaryotic.eukaryota_odb10_h.dbtype
│   │   ├── microeukaryotic.eukaryota_odb10_h.index
│   │   ├── microeukaryotic.eukaryota_odb10.index
│   │   ├── microeukaryotic.eukaryota_odb10.lookup
│   │   ├── microeukaryotic.eukaryota_odb10.source
│   │   ├── microeukaryotic_h
│   │   ├── microeukaryotic_h.dbtype
│   │   ├── microeukaryotic_h.index
│   │   ├── microeukaryotic.index
│   │   ├── microeukaryotic.lookup
│   │   ├── microeukaryotic.source
│   │   ├── reference.eukaryota_odb10.list
│   │   ├── RELEASE_NOTES
│   │   ├── source_taxonomy.tsv.gz
│   │   ├── source_to_lineage.dict.pkl.gz
│   │   └── target_to_source.dict.pkl.gz
│   └── NCBITaxonomy
│       ├── citations.dmp
│       ├── delnodes.dmp
│       ├── division.dmp
│       ├── gc.prt
│       ├── gencode.dmp
│       ├── merged.dmp
│       ├── names.dmp
│       ├── nodes.dmp
│       ├── prot.accession2taxid.FULL.gz
│       └── readme.txt
├── Contamination
│   ├── AntiFam
│   │   ├── AntiFam.hmm.gz
│   │   ├── relnotes
│   │   └── version
│   ├── chm13v2.0
│   │   ├── chm13v2.0.1.bt2
│   │   ├── chm13v2.0.2.bt2
│   │   ├── chm13v2.0.3.bt2
│   │   ├── chm13v2.0.4.bt2
│   │   ├── chm13v2.0.rev.1.bt2
│   │   └── chm13v2.0.rev.2.bt2
│   └── kmers
│       └── ribokmers.fa.gz
└── MarkerSets
    ├── Archaea_76.hmm.gz
    ├── Bacteria_71.hmm.gz
    ├── CPR_43.hmm.gz
    ├── eukaryota_odb10.hmm.gz
    ├── eukaryota_odb10.scores_cutoff.tsv.gz
    ├── Fungi_593.hmm.gz
    ├── Protista_83.hmm.gz
    └── README

31 directories, 96 files
```
</details>


<details>
	<summary>*VEBA Database* version: VDB_v3.1</summary>
	
The same as `VDB_v3` but updates `VDB-Microeukaryotic_v2` to `VDB-Microeukaryotic_v2.1` which has a `reference.eukaryota_odb10.list` containing only the subset of identifiers that core eukaryotic markers (useful for classification).
	
```
tree -L 3 .
.
├── ACCESS_DATE
├── Annotate
│   ├── KOFAM
│   │   ├── ko_list
│   │   └── profiles
│   ├── nr
│   │   └── nr.dmnd
│   └── Pfam
│       └── Pfam-A.hmm.gz
├── Classify
│   ├── CheckM
│   │   ├── distributions
│   │   ├── genome_tree
│   │   ├── hmms
│   │   ├── hmms_ssu
│   │   ├── img
│   │   ├── pfam
│   │   ├── selected_marker_sets.tsv
│   │   ├── taxon_marker_sets.tsv
│   │   └── test_data
│   ├── CheckV
│   │   ├── genome_db
│   │   ├── hmm_db
│   │   └── README.txt
│   ├── GTDBTk
│   │   ├── fastani
│   │   ├── markers
│   │   ├── masks
│   │   ├── metadata
│   │   ├── mrca_red
│   │   ├── msa
│   │   ├── pplacer
│   │   ├── radii
│   │   ├── split
│   │   ├── taxonomy
│   │   └── temp
│   ├── Microeukaryotic
│   │   ├── humann_uniref50_annotations.tsv.gz
│   │   ├── md5_checksums
│   │   ├── microeukaryotic
│   │   ├── microeukaryotic.dbtype
│   │   ├── microeukaryotic.eukaryota_odb10
│   │   ├── microeukaryotic.eukaryota_odb10.dbtype
│   │   ├── microeukaryotic.eukaryota_odb10_h
│   │   ├── microeukaryotic.eukaryota_odb10_h.dbtype
│   │   ├── microeukaryotic.eukaryota_odb10_h.index
│   │   ├── microeukaryotic.eukaryota_odb10.index
│   │   ├── microeukaryotic.eukaryota_odb10.lookup
│   │   ├── microeukaryotic.eukaryota_odb10.source
│   │   ├── microeukaryotic_h
│   │   ├── microeukaryotic_h.dbtype
│   │   ├── microeukaryotic_h.index
│   │   ├── microeukaryotic.index
│   │   ├── microeukaryotic.lookup
│   │   ├── microeukaryotic.source
│   │   ├── reference.eukaryota_odb10.list
│   │   ├── reference.eukaryota_odb10.list.md5
│   │   ├── reference.faa.gz
│   │   ├── RELEASE_NOTES
│   │   ├── source_taxonomy.tsv.gz
│   │   ├── source_to_lineage.dict.pkl.gz
│   │   └── target_to_source.dict.pkl.gz
│   └── NCBITaxonomy
│       ├── citations.dmp
│       ├── delnodes.dmp
│       ├── division.dmp
│       ├── gc.prt
│       ├── gencode.dmp
│       ├── merged.dmp
│       ├── names.dmp
│       ├── nodes.dmp
│       ├── prot.accession2taxid.FULL.gz
│       ├── readme.txt
│       ├── taxa.sqlite
│       └── taxa.sqlite.traverse.pkl
├── Contamination
│   ├── chm13v2.0
│   │   ├── chm13v2.0.1.bt2
│   │   ├── chm13v2.0.2.bt2
│   │   ├── chm13v2.0.3.bt2
│   │   ├── chm13v2.0.4.bt2
│   │   ├── chm13v2.0.rev.1.bt2
│   │   └── chm13v2.0.rev.2.bt2
│   └── kmers
│       └── ribokmers.fa.gz
├── MarkerSets
│   ├── Archaea_76.hmm
│   ├── Bacteria_71.hmm
│   ├── CPR_43.hmm
│   ├── eukaryota_odb10.hmm
│   ├── eukaryota_odb10.scores_cutoff.tsv.gz
│   ├── Fungi_593.hmm
│   ├── Protista_83.hmm
│   └── README
└── SIZE

35 directories, 60 files
```
</details>


<details>
	<summary>*VEBA Database* version: VDB_v3</summary>

```
tree -L 3 .
.
├── ACCESS_DATE
├── Annotate
│   ├── KOFAM
│   │   ├── ko_list
│   │   └── profiles
│   ├── nr
│   │   └── nr.dmnd
│   └── Pfam
│       └── Pfam-A.hmm.gz
├── Classify
│   ├── CheckM
│   │   ├── distributions
│   │   ├── genome_tree
│   │   ├── hmms
│   │   ├── hmms_ssu
│   │   ├── img
│   │   ├── pfam
│   │   ├── selected_marker_sets.tsv
│   │   ├── taxon_marker_sets.tsv
│   │   └── test_data
│   ├── CheckV
│   │   ├── genome_db
│   │   ├── hmm_db
│   │   └── README.txt
│   ├── GTDBTk
│   │   ├── fastani
│   │   ├── markers
│   │   ├── masks
│   │   ├── metadata
│   │   ├── mrca_red
│   │   ├── msa
│   │   ├── pplacer
│   │   ├── radii
│   │   ├── split
│   │   ├── taxonomy
│   │   └── temp
│   ├── Microeukaryotic
│   │   ├── humann_uniref50_annotations.tsv.gz
│   │   ├── md5_checksums
│   │   ├── microeukaryotic
│   │   ├── microeukaryotic.dbtype
│   │   ├── microeukaryotic_h
│   │   ├── microeukaryotic_h.dbtype
│   │   ├── microeukaryotic_h.index
│   │   ├── microeukaryotic.index
│   │   ├── microeukaryotic.lookup
│   │   ├── microeukaryotic.source
│   │   ├── reference.faa.gz
│   │   ├── RELEASE_NOTES
│   │   ├── source_taxonomy.tsv.gz
│   │   ├── source_to_lineage.dict.pkl.gz
│   │   └── target_to_source.dict.pkl.gz
│   └── NCBITaxonomy
│       ├── citations.dmp
│       ├── delnodes.dmp
│       ├── division.dmp
│       ├── gc.prt
│       ├── gencode.dmp
│       ├── merged.dmp
│       ├── names.dmp
│       ├── nodes.dmp
│       ├── prot.accession2taxid.FULL.gz
│       ├── readme.txt
│       ├── taxa.sqlite
│       └── taxa.sqlite.traverse.pkl
├── Contamination
│   ├── chm13v2.0
│   │   ├── chm13v2.0.1.bt2
│   │   ├── chm13v2.0.2.bt2
│   │   ├── chm13v2.0.3.bt2
│   │   ├── chm13v2.0.4.bt2
│   │   ├── chm13v2.0.rev.1.bt2
│   │   └── chm13v2.0.rev.2.bt2
│   └── kmers
│       └── ribokmers.fa.gz
├── MarkerSets
│   ├── Archaea_76.hmm
│   ├── Bacteria_71.hmm
│   ├── CPR_43.hmm
│   ├── eukaryota_odb10.hmm
│   ├── eukaryota_odb10.scores_cutoff.tsv.gz
│   ├── Fungi_593.hmm
│   ├── Protista_83.hmm
│   └── README
└── SIZE

35 directories, 50 files
```

</details>


<details>
	<summary>*VEBA Database* version: VDB_v2</summary>
	
* Compatible with *VEBA* version: `v1.0.2a+`
	

```
tree -L 3 .
.
├── ACCESS_DATE
├── Annotate
│   ├── KOFAM
│   │   ├── ko_list
│   │   └── profiles
│   ├── nr
│   │   └── nr.dmnd
│   └── Pfam
│       └── Pfam-A.hmm.gz
├── Classify
│   ├── CheckM
│   │   ├── distributions
│   │   ├── genome_tree
│   │   ├── hmms
│   │   ├── hmms_ssu
│   │   ├── img
│   │   ├── pfam
│   │   ├── selected_marker_sets.tsv
│   │   ├── taxon_marker_sets.tsv
│   │   └── test_data
│   ├── CheckV
│   │   ├── genome_db
│   │   ├── hmm_db
│   │   └── README.txt
│   ├── GTDBTk
│   │   ├── fastani
│   │   ├── markers
│   │   ├── masks
│   │   ├── metadata
│   │   ├── mrca_red
│   │   ├── msa
│   │   ├── pplacer
│   │   ├── radii
│   │   ├── split
│   │   ├── taxonomy
│   │   └── temp
│   ├── Microeukaryotic
│   │   ├── microeukaryotic
│   │   ├── microeukaryotic.dbtype
│   │   ├── microeukaryotic_h
│   │   ├── microeukaryotic_h.dbtype
│   │   ├── microeukaryotic_h.index
│   │   ├── microeukaryotic.index
│   │   ├── microeukaryotic.lookup
│   │   ├── microeukaryotic.source
│   │   ├── reference.rmdup.iupac.relabeled.no_deprecated.complete_lineage.faa.gz
│   │   ├── source_taxonomy.tsv.gz
│   │   ├── source_to_lineage.dict.pkl.gz
│   │   └── target_to_source.dict.pkl.gz
│   └── NCBITaxonomy
│       ├── citations.dmp
│       ├── delnodes.dmp
│       ├── division.dmp
│       ├── gc.prt
│       ├── gencode.dmp
│       ├── merged.dmp
│       ├── names.dmp
│       ├── nodes.dmp
│       ├── prot.accession2taxid.FULL.gz
│       ├── readme.txt
│       ├── taxa.sqlite
│       └── taxa.sqlite.traverse.pkl
├── Contamination
│   ├── chm13v2.0
│   │   ├── chm13v2.0.1.bt2
│   │   ├── chm13v2.0.2.bt2
│   │   ├── chm13v2.0.3.bt2
│   │   ├── chm13v2.0.4.bt2
│   │   ├── chm13v2.0.rev.1.bt2
│   │   └── chm13v2.0.rev.2.bt2
│   └── kmers
│       └── ribokmers.fa.gz
├── MarkerSets
│   ├── Archaea_76.hmm
│   ├── Bacteria_71.hmm
│   ├── CPR_43.hmm
│   ├── eukaryota_odb10.hmm
│   ├── eukaryota_odb10.scores_cutoff.tsv.gz
│   ├── Fungi_593.hmm
│   ├── Protista_83.hmm
│   └── README
└── SIZE

35 directories, 47 files

```
</details>


<details>
	<summary>*VEBA Database* version: VDB_v1</summary>
	

* Compatible with *VEBA* version: `v1.0.0`, `v1.0.1`
	
	
```
tree -L 3 .
.
├── ACCESS_DATE
├── Annotate
│   ├── KOFAM
│   │   ├── ko_list
│   │   └── profiles
│   ├── nr
│   │   └── nr.dmnd
│   └── Pfam
│       └── Pfam-A.hmm.gz
├── Classify
│   ├── CheckM
│   │   ├── distributions
│   │   ├── genome_tree
│   │   ├── hmms
│   │   ├── hmms_ssu
│   │   ├── img
│   │   ├── pfam
│   │   ├── selected_marker_sets.tsv
│   │   ├── taxon_marker_sets.tsv
│   │   └── test_data
│   ├── CheckV
│   │   ├── genome_db
│   │   ├── hmm_db
│   │   └── README.txt
│   ├── GTDBTk
│   │   ├── fastani
│   │   ├── markers
│   │   ├── masks
│   │   ├── metadata
│   │   ├── mrca_red
│   │   ├── msa
│   │   ├── pplacer
│   │   ├── radii
│   │   ├── split
│   │   ├── taxonomy
│   │   └── temp
│   ├── Microeukaryotic
│   │   ├── humann_uniref50_annotations.tsv.gz
│   │   ├── md5_checksums
│   │   ├── microeukaryotic
│   │   ├── microeukaryotic.dbtype
│   │   ├── microeukaryotic.eukaryota_odb10
│   │   ├── microeukaryotic.eukaryota_odb10.dbtype
│   │   ├── microeukaryotic.eukaryota_odb10_h
│   │   ├── microeukaryotic.eukaryota_odb10_h.dbtype
│   │   ├── microeukaryotic.eukaryota_odb10_h.index
│   │   ├── microeukaryotic.eukaryota_odb10.index
│   │   ├── microeukaryotic.eukaryota_odb10.lookup
│   │   ├── microeukaryotic.eukaryota_odb10.source
│   │   ├── microeukaryotic_h
│   │   ├── microeukaryotic_h.dbtype
│   │   ├── microeukaryotic_h.index
│   │   ├── microeukaryotic.index
│   │   ├── microeukaryotic.lookup
│   │   ├── microeukaryotic.source
│   │   ├── reference.eukaryota_odb10.list
│   │   ├── reference.eukaryota_odb10.list.md5
│   │   ├── reference.faa.gz
│   │   ├── RELEASE_NOTES
│   │   ├── source_taxonomy.tsv.gz
│   │   ├── source_to_lineage.dict.pkl.gz
│   │   └── target_to_source.dict.pkl.gz
│   └── NCBITaxonomy
│       ├── citations.dmp
│       ├── delnodes.dmp
│       ├── division.dmp
│       ├── gc.prt
│       ├── gencode.dmp
│       ├── merged.dmp
│       ├── names.dmp
│       ├── nodes.dmp
│       ├── prot.accession2taxid.FULL.gz
│       ├── readme.txt
│       ├── taxa.sqlite
│       └── taxa.sqlite.traverse.pkl
├── Contamination
│   ├── chm13v2.0
│   │   ├── chm13v2.0.1.bt2
│   │   ├── chm13v2.0.2.bt2
│   │   ├── chm13v2.0.3.bt2
│   │   ├── chm13v2.0.4.bt2
│   │   ├── chm13v2.0.rev.1.bt2
│   │   └── chm13v2.0.rev.2.bt2
│   └── kmers
│       └── ribokmers.fa.gz
├── MarkerSets
│   ├── Archaea_76.hmm
│   ├── Bacteria_71.hmm
│   ├── CPR_43.hmm
│   ├── eukaryota_odb10.hmm
│   ├── eukaryota_odb10.scores_cutoff.tsv.gz
│   ├── Fungi_593.hmm
│   ├── Protista_83.hmm
│   └── README
└── SIZE

35 directories, 60 files
```
	
```
tree -L 3 .
.
.
├── ACCESS_DATE
├── Annotate
│   ├── KOFAM
│   │   ├── ko_list
│   │   └── profiles
│   ├── nr
│   │   └── nr.dmnd
│   └── Pfam
│       └── Pfam-A.hmm.gz
├── Classify
│   ├── CheckM
│   │   ├── distributions
│   │   ├── genome_tree
│   │   ├── hmms
│   │   ├── hmms_ssu
│   │   ├── img
│   │   ├── pfam
│   │   ├── selected_marker_sets.tsv
│   │   ├── taxon_marker_sets.tsv
│   │   └── test_data
│   ├── CheckV
│   │   ├── genome_db
│   │   ├── hmm_db
│   │   └── README.txt
│   ├── GTDBTk
│   │   ├── fastani
│   │   ├── manifest.tsv
│   │   ├── markers
│   │   ├── masks
│   │   ├── metadata
│   │   ├── mrca_red
│   │   ├── msa
│   │   ├── pplacer
│   │   ├── radii
│   │   └── taxonomy
│   ├── Microeukaryotic
│   │   ├── microeukaryotic
│   │   ├── microeukaryotic.dbtype
│   │   ├── microeukaryotic_h
│   │   ├── microeukaryotic_h.dbtype
│   │   ├── microeukaryotic_h.index
│   │   ├── microeukaryotic.index
│   │   ├── microeukaryotic.lookup
│   │   ├── microeukaryotic.source
│   │   ├── reference.rmdup.iupac.relabeled.no_deprecated.complete_lineage.faa.gz
│   │   ├── source_taxonomy.tsv.gz
│   │   ├── source_to_lineage.dict.pkl.gz
│   │   └── target_to_source.dict.pkl.gz
│   └── NCBITaxonomy
│       ├── citations.dmp
│       ├── delnodes.dmp
│       ├── division.dmp
│       ├── gc.prt
│       ├── gencode.dmp
│       ├── merged.dmp
│       ├── names.dmp
│       ├── nodes.dmp
│       ├── prot.accession2taxid.FULL.gz
│       ├── readme.txt
│       ├── taxa.sqlite
│       └── taxa.sqlite.traverse.pkl
├── Contamination
│   ├── grch38
│   │   ├── GCA_000001405.15_GRCh38_no_alt_analysis_set.fna.bowtie_index.1.bt2
│   │   ├── GCA_000001405.15_GRCh38_no_alt_analysis_set.fna.bowtie_index.2.bt2
│   │   ├── GCA_000001405.15_GRCh38_no_alt_analysis_set.fna.bowtie_index.3.bt2
│   │   ├── GCA_000001405.15_GRCh38_no_alt_analysis_set.fna.bowtie_index.4.bt2
│   │   ├── GCA_000001405.15_GRCh38_no_alt_analysis_set.fna.bowtie_index.rev.1.bt2
│   │   └── GCA_000001405.15_GRCh38_no_alt_analysis_set.fna.bowtie_index.rev.2.bt2
│   └── kmers
│       └── ribokmers.fa.gz
└── MarkerSets
    ├── Archaea_76.hmm
    ├── Bacteria_71.hmm
    ├── CPR_43.hmm
    ├── eukaryota_odb10.hmm
    ├── eukaryota_odb10.scores_cutoff.tsv.gz
    ├── Fungi_593.hmm
    ├── Protista_83.hmm
    └── README

33 directories, 47 files
```

</details>


____________________________________________________________

#### Version Notes:

* The `nr.dmnd` should be built using NCBI's taxonomy info.  The `download_database.sh` takes care of this but if you are using a prebuilt `nr.dmnd` database then use following command for reference: `diamond makedb --in ${DATABASE_DIRECTORY}/nr.gz --db ${DATABASE_DIRECTORY}/Annotate/nr.dmnd --taxonmap ${DATABASE_DIRECTORY}/Classify/NCBITaxonomy/prot.accession2taxid.FULL.gz --taxonnodes ${DATABASE_DIRECTORY}/Classify/NCBITaxonomy/nodes.dmp --taxonnames ${DATABASE_DIRECTORY}/Classify/NCBITaxonomy/names.dmp`
* The NCBI taxonomy should be downloaded on the same date as NR to make sure the identifiers match up between datasets.  NCBI deprecates taxonomy identifiers and adds new ones between versions so downloading on the same day should minimize that discrepancy.  One caveat NCBI NR and taxonomy databases is the versioning is difficult to discern.
* For the human contamination, if you use `KneadData` and already have a `Bowtie2` index for human then you can use that instead.  The only module that uses this is `preprocess.py` and you have to specify this directly when running (i.e., it's optional) so it doesn't matter if it's in the database directory or not (same with ribokmers.fa.gz). 
* `CheckM2` only has 1 database version at this time so it isn't an issue. 
* `KOFAM` and `Pfam` just uses these as annotations so any version should work perfectly.
* Again, if you are low on disk space and already have these installed then just symlink them with the structure above. If so, them just comment out those sections of `download_databases.sh`.  

_______________________________________________________
**VEBA v1.1.0 Specific Versions:**
* As of `v1.1.0` *VEBA* requires `CheckM2` database instead of `CheckM` database, the `geNomad` database, and v1.5 `CheckV` database.


**VEBA v1.0.2a Specific Versions:**

* As of `v1.0.2a` *VEBA* uses *GTDB-Tk v2.x* which requires *GTDB R207_v2* and above. If you are using *GTDB-Tk v1.0.0/1* then you will need to use either *GTDB R202/R207*.

**VEBA v1.0.0/1 Specific Versions:**

* The only mandatory datbase version is `R202` for `GTDBTk` because `VEBA` is built on `v1.5.0 ≤ GTDBTk ≤ v1.70`.  The next major `VEBA` update will upgrade to `≥ GTDBTk v2.0.0` and the associated `R207_v2` database.

_______________________________________________________

If you have any issues, please create a GitHub issue with the prefix `[Database]` followed by the question.